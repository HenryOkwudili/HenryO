#include <iostream>
#include <cmath>
using namespace std;
int main()
{
	int v;
	int a;
	cout<<"input surface area of cube :";
	cin>>a;
	
	v = pow(a,3);
	
	cout<<"Volume of the cube is :"<<v;
	
	return 0;
}
